#include <windows.h>
#include<cstdio>
#include <GL/gl.h>
#include <GL/glut.h>
#include<math.h>>

# define PI           3.14159265358979323846

GLfloat position = 0.7f;
GLfloat position2 = 0.0f;
GLfloat speed = 0.05f;

void update(int value)
{
    if(position <-0.3f)
        position = 0.75f;
    position -= speed;

glutPostRedisplay();
glutTimerFunc(100, update, 0);
}

void sound()
{


    PlaySound("car-horn.wav", NULL,SND_ASYNC|SND_FILENAME);

}

void SpecialInput(int key, int x, int y)
{
switch(key)
{
case GLUT_KEY_UP:
speed = 0.05f;
break;
case GLUT_KEY_DOWN:
speed = 0.0f;
break;
case GLUT_KEY_LEFT:
break;
case GLUT_KEY_RIGHT:
break;
}
glutPostRedisplay();
}
void handleKeypress(unsigned char key, int x, int y)
{
	switch (key)
    {
    case 'w':
        sound();
        break;


    glutPostRedisplay();

	}
}

void circle( float x1, float y1 , float Radius,int j,int l,int h)
 {

int i;
  GLfloat x=x1; GLfloat y=y1; GLfloat radius =Radius;
  int triangleAmount = 100; //# of lines used to draw circle

//GLfloat radius = 0.8f; //radius
  GLfloat twicePi = 2.0f * PI;

glColor3ub(j, l, h);
  glBegin(GL_TRIANGLE_FAN);
  glVertex2f(x, y); // center of circle
  for(i = 0; i <= triangleAmount;i++) {
  glVertex2f( x + (radius * cos(i * twicePi / triangleAmount)),
 y + (radius * sin(i * twicePi / triangleAmount)) );
  }
  glEnd();

}
void drawGrass(float x, float y) {
    glBegin(GL_LINES);
    glColor3ub(255,255,255); // Set grass color (green)

    // Grass blades
    glVertex2f(x - 0.6f, y - 0.1f);
    glVertex2f(x - 0.6f, y - 0.18f);

    glVertex2f(x - 0.62f, y - 0.1f);
    glVertex2f(x - 0.6f, y - 0.12f);

    glVertex2f(x - 0.58f, y - 0.1f);
    glVertex2f(x - 0.6f, y - 0.12f);

    glVertex2f(x - 0.62f, y - 0.12f);
    glVertex2f(x - 0.6f, y - 0.14f);

    glVertex2f(x - 0.58f, y - 0.12f);
    glVertex2f(x - 0.6f, y - 0.14f);

    glVertex2f(x - 0.62f, y - 0.14f);
    glVertex2f(x - 0.6f, y - 0.16f);

    glVertex2f(x - 0.58f, y - 0.14f);
    glVertex2f(x - 0.6f, y - 0.16f);

    glEnd();
}

void init(){
  glClearColor(1.0f, 1.0f, 1.0f, 0.0f);

  };

void display(){
      glBegin(GL_QUADS);
    glColor3ub(0, 128, 0);

    glVertex2f(-.7f, 0.0f);
    glVertex2f(.7f, 0.0f);
    glVertex2f(.7f, .16f);
    glVertex2f(-.7f, 0.16f);

    glEnd();



    glBegin(GL_QUADS);
    glColor3ub(135, 206, 235);

    glVertex2f(-.7f, .16f);
    glVertex2f(-.7f, 0.5f);
    glVertex2f(.7f, .5f);
    glVertex2f(.7f, .16f);

    glEnd();


    glBegin(GL_POLYGON);
    glColor3ub(101, 67, 33);



    glVertex2f(-.7f, 0.16f);
    glVertex2f(-.4f, 0.4f);
    glVertex2f(0.0f, 0.16f);




    glEnd();
    glBegin(GL_POLYGON);
    glColor3ub(101, 67, 33);



    glVertex2f(-.2f, 0.16f);
    glVertex2f(0.0f, 0.5f);
    glVertex2f(0.4f, 0.16f);




    glEnd();
    glBegin(GL_POLYGON);
    glColor3ub(101, 67, 33);



    glVertex2f(0.0f, 0.16f);
    glVertex2f(.4f, 0.4f);
    glVertex2f(0.7f, 0.16f);




    glEnd();
    glBegin(GL_POLYGON);
    glColor3ub(169, 169, 169);



    glVertex2f(-.6f, 0.16f);
    glVertex2f(-.46f, 0.3f);
    glVertex2f(0.2f, 0.16f);




    glEnd();
    glBegin(GL_POLYGON);
    glColor3ub(169, 169, 169);



    glVertex2f(-.16f, 0.16f);
    glVertex2f(0.0f, 0.4f);
    glVertex2f(0.38f, 0.16f);




    glEnd();
    glBegin(GL_POLYGON);
    glColor3ub(169, 169, 169);



    glVertex2f(0.0f, 0.16f);
    glVertex2f(.32f, 0.32f);
    glVertex2f(0.68f, 0.16f);




    glEnd();


  circle(0.0,0.3,0.12,139, 0, 0);
  circle(0.16,0.26,0.06,139, 0, 0);
  circle(0.26,0.24,0.05,139, 0, 0);
  circle(-0.24,0.26,0.06,139, 0, 0);
  circle(-0.35,0.24,0.06,139, 0, 0);

    glBegin(GL_QUADS);
    glColor3ub(34, 139, 34);

    glVertex2f(-.7f, .16f);
    glVertex2f(.7f, .16f);
    glVertex2f(.7f, -.5f);
    glVertex2f(-.7f, -.5f);

    glEnd();

      glBegin(GL_QUADS);
    glColor3ub(0, 100, 0);

    glVertex2f(-.7f, 0.0f);
    glVertex2f(.7f, 0.0f);
    glVertex2f(.7f, .16f);
    glVertex2f(-.7f, 0.16f);

    glEnd();
//road
     glBegin(GL_QUADS);
    glColor3ub(50, 50, 50);
    glVertex2f(-.7f, -.2f);
    glVertex2f(-0.7f, -.45f);
    glVertex2f( .7f, -0.45f);
    glVertex2f(.7f, -.2f);

    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(70, 70, 70);
    glVertex2f(0.0f, -.1f);
    glVertex2f( .3f, 0.0f);
    glVertex2f(.3f, .2f);
    glVertex2f(0.0f, .3f);
    glVertex2f(0.0f, -.1f);
    glVertex2f(0.0f, .3f);
    glVertex2f(-.4f, 0.2f);
    glVertex2f(-.4f, 0.0f);


    glEnd();
      glBegin(GL_QUADS);
    glColor3ub(0, 0, 0);

    glVertex2f(0.0f, -.08f);
    glVertex2f( .3f, 0.02f);
    glVertex2f(.3f, .16f);
    glVertex2f(0.0f, .26f);
    glVertex2f(-.4f, 0.16f);
    glVertex2f(-.4f, 0.02f);


    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(0, 0, 0);

    glVertex2f(0.0f, -.08f);
    glVertex2f(0.0f, .26f);
    glVertex2f(-.4f, 0.16f);
    glVertex2f(-.4f, 0.02f);


    glEnd();

       glBegin(GL_POLYGON);

    glColor3ub(105, 105, 105);
    glVertex2f(0.0f, -0.08f);
    glVertex2f(0.06f, -.06f);
    glVertex2f(0.06f, .24f);
    glVertex2f(0.0f, 0.26f);
    glVertex2f(-.08f, 0.24f);
    glVertex2f(-.08f, -0.06f);





    glEnd();
glBegin(GL_QUADS);
    glColor3ub(70, 70, 70);


    glVertex2f(0.1f, -.06f);
    glVertex2f(0.16f, -.04f);
    glVertex2f(0.16f, 0.06f);
    glVertex2f(0.1f, 0.06f);


    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(70, 70, 70);


    glVertex2f(0.2f, -.02f);
    glVertex2f(0.26f, 0.0f);
    glVertex2f(0.26f, 0.08f);
    glVertex2f(0.2f, 0.08f);


    glEnd();
      glBegin(GL_QUADS);
    glColor3ub(70, 70, 70);


    glVertex2f(-.14f, -.06f);
    glVertex2f(-.2f, -.04f);
    glVertex2f(-.2f, 0.12f);
    glVertex2f(-.14f, 0.12f);


    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(70, 70, 70);


    glVertex2f(-.24f, -.04f);
    glVertex2f(-.3f, -.02f);
    glVertex2f(-.3f, 0.1f);
    glVertex2f(-.24f, 0.1f);


    glEnd();

     glBegin(GL_QUADS);
    glColor3ub(70, 70, 70);


    glVertex2f(-.32f, -.02f);
    glVertex2f(-.36f, 0.0f);
    glVertex2f(-.36f, 0.08f);
    glVertex2f(-.32f, 0.08f);


    glEnd();

     glBegin(GL_POLYGON);
    glColor3ub(139, 0, 0);



    glVertex2f(-.1f, .27f);
    glVertex2f(-.1f, 0.32f);
    glVertex2f(-.16f, 0.36f);
    glVertex2f(-.24f, 0.3f);
     glVertex2f(-.24f, 0.24f);


    glEnd();




        circle(-0.27,0.12,0.03,70, 70, 70);
       circle(-0.17,0.14,0.03,70, 70, 70);
       circle(0.13,0.08,0.03,70, 70, 70);
       circle(0.23,0.1,0.03,70, 70, 70);

glBegin(GL_POLYGON);
    glColor3ub(139, 69, 19);



    glVertex2f(-.58f, 0.0f);
    glVertex2f(-.58f, 0.1f);
    glVertex2f(-.6f, 0.1f);
    glVertex2f(-.6f, 0.0f);



    glEnd();
glBegin(GL_POLYGON);
    glColor3ub(0, 80, 0);



    glVertex2f(-.54f, 0.08f);
    glVertex2f(-.59f, 0.13f);
    glVertex2f(-.64f, 0.08f);




    glEnd();
    glBegin(GL_POLYGON);
    glColor3ub(139, 69, 19);



    glVertex2f(.58f, 0.0f);
    glVertex2f(.58f, 0.1f);
    glVertex2f(.6f, 0.1f);
    glVertex2f(.6f, 0.0f);



    glEnd();
glBegin(GL_POLYGON);
    glColor3ub(0, 80, 0);



    glVertex2f(.54f, 0.08f);
    glVertex2f(.59f, 0.13f);
    glVertex2f(.64f, 0.08f);




    glEnd();
glBegin(GL_POLYGON);
    glColor3ub(139, 69, 19);



    glVertex2f(-.46f, 0.0f);
    glVertex2f(-.46f, 0.16f);
    glVertex2f(-.5f, 0.16f);
    glVertex2f(-.5f, 0.0f);



    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(139, 69, 19);



    glVertex2f(.46f, 0.0f);
    glVertex2f(.46f, 0.16f);
    glVertex2f(.5f, 0.16f);
    glVertex2f(.5f, 0.0f);



    glEnd();
    //Car
glPushMatrix();
    glTranslatef(position,0.0f, 0.0f);

    glBegin(GL_POLYGON);
   glColor3ub(255, 255, 255);


    glVertex2f(-.4f, -.36f);
    glVertex2f(-.35f,-.36f);
    glVertex2f(-.3f, -0.3f);
    glVertex2f(-.2f, -0.3f);
    glVertex2f(-.15f, -0.36f);
    glVertex2f(-.1f, -0.36f);
    glVertex2f(-.1f, -0.4f);
    glVertex2f(-.4f, -0.4f);

    glEnd();

     circle(-0.31,-0.4,0.04,0,0,0);
     circle(-0.19,-0.4,0.04,0,0,0);

glPopMatrix();
  glFlush();



//Grass
glBegin(GL_POLYGON);
    glColor3ub(0, 80, 0);



    glVertex2f(.42f, 0.14f);
    glVertex2f(.48f, 0.2f);
    glVertex2f(.54f, 0.14f);




    glEnd();
    glBegin(GL_POLYGON);
    glColor3ub(0, 80, 0);



    glVertex2f(-.42f, 0.14f);
    glVertex2f(-.48f, 0.2f);
    glVertex2f(-.54f, 0.14f);




    glEnd();

    //Birds
    glPushMatrix();
    glTranslatef(position,0.0f, 0.0f);

    glBegin(GL_LINES);
    glColor3ub(0, 0, 0);
    glVertex2f(-0.6f, 0.4f);
    glVertex2f(-0.58f, 0.38f);

    glVertex2f(-0.58f, 0.38f);
    glVertex2f(-0.56f, 0.4f);

    glVertex2f(-0.56f, 0.38f);
    glVertex2f(-0.54f, 0.36f);

    glVertex2f(-0.54f, 0.36f);
    glVertex2f(-0.52f, 0.38f);

    glVertex2f(-0.52f, 0.36f);
    glVertex2f(-0.5f, 0.34f);

    glVertex2f(-0.5f, 0.34f);
    glVertex2f(-0.48f, 0.36f);

    glVertex2f(-0.56f, 0.34f);
    glVertex2f(-0.54f, 0.32f);

    glVertex2f(-0.54f, 0.32f);
    glVertex2f(-0.52f, 0.34f);

glEnd();
 glBegin(GL_LINES);
    glColor3ub(0, 0, 0);
    glVertex2f(0.6f, 0.4f);
    glVertex2f(0.58f, 0.38f);

    glVertex2f(0.58f, 0.38f);
    glVertex2f(0.56f, 0.4f);

    glVertex2f(0.56f, 0.38f);
    glVertex2f(0.54f, 0.36f);

    glVertex2f(0.54f, 0.36f);
    glVertex2f(0.52f, 0.38f);

    glVertex2f(0.52f, 0.36f);
    glVertex2f(0.5f, 0.34f);

    glVertex2f(0.5f, 0.34f);
    glVertex2f(0.48f, 0.36f);

    glVertex2f(0.56f, 0.34f);
    glVertex2f(0.54f, 0.32f);

    glVertex2f(0.54f, 0.32f);
    glVertex2f(0.52f, 0.34f);

glEnd();
glPopMatrix();





  glBegin(GL_LINES);
    glColor3ub(0, 0, 0);

    glVertex2f(-0.6f, -0.1f);
    glVertex2f(-0.6f, -0.18f);

       glVertex2f(-0.62f, -0.1f);
    glVertex2f(-0.6f, -0.12f);

       glVertex2f(-0.58f, -0.1f);
    glVertex2f(-0.6f, -0.12f);

      glVertex2f(-0.62f, -0.12f);
    glVertex2f(-0.6f, -0.14f);

       glVertex2f(-0.58f, -0.12f);
    glVertex2f(-0.6f, -0.14f);

          glVertex2f(-0.62f, -0.14f);
    glVertex2f(-0.6f, -0.16f);

       glVertex2f(-0.58f, -0.14f);
    glVertex2f(-0.6f, -0.16f);


glEnd();
glPopMatrix();

    drawGrass(0.0f, 0.0f);
    drawGrass(0.1f, 0.0f);
    drawGrass(0.2f, 0.0f);
    drawGrass(0.3f, 0.0f);
    drawGrass(0.4f, 0.0f);
    drawGrass(0.5f, 0.0f);
    drawGrass(0.8f, 0.0f);
    drawGrass(0.9f, 0.0f);
    drawGrass(1.0f, 0.0f);
    drawGrass(1.1f, 0.0f);
    drawGrass(1.2f, 0.0f);





    glFlush();

};

int main(int argc, char** argv) {
   glutInit(&argc, argv);
   glutInitWindowSize(1200, 600);
   glutInitWindowPosition(80, 50);
   glutCreateWindow(" Performance");
   glutDisplayFunc(display);
   glutSpecialFunc(SpecialInput);
   glutKeyboardFunc(handleKeypress);
   glutTimerFunc(100, update, 0);
   init();


   glutMainLoop();
   return 0;
}
